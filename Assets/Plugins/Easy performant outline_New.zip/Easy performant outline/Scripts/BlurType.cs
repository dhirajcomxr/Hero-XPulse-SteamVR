﻿namespace EPOOutline
{
    public enum BlurType
    {
        Anisotropic,
        Box,
        Gaussian5x5,
        Gaussian9x9,
        Gaussian13x13
    }
}